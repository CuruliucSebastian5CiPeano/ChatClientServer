/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatclient;

import java.net.SocketException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pc15
 */
public class ChatClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         try {
            ClientUDP client = new ClientUDP(9090, "localhost", 9090);
            new Ricevi(client);
            
            Scanner sc = new Scanner(System.in);
            
            System.out.println("Inserisci Username: ");
            String username = sc.nextLine();
            
            while(true) {
                String text = sc.nextLine();
                new Manda(client, ("["+ username +"] : "+text) );
            }
            
        } catch (SocketException ex) {
            Logger.getLogger(ChatClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    

