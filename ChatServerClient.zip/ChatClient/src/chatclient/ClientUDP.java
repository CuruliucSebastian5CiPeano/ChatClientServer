/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatclient;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author pc15
 */
public class ClientUDP {
    
    private DatagramSocket datagramSocket;
    private String serverIP;
    private int serverPORT;
    
    public ClientUDP(int portClient, String ip, int portServer) throws SocketException{
        datagramSocket = new DatagramSocket(portClient);
        this.serverIP = ip;
        this.serverPORT = portServer;
    }
    
    public void manda(String testo) throws UnknownHostException, IOException{
        byte[] buffer = new byte[100];
        buffer = testo.getBytes("UTF-8");
        DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(serverIP), this.serverPORT);
        this.datagramSocket.send(dp);
    }
    
    public String ricevi() throws IOException {
        byte[] buffer = new byte[100];
        DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
        this.datagramSocket.receive(dp);
        String text = new String(dp.getData(), "ISO-8859-1");
        return text;
    }
}
